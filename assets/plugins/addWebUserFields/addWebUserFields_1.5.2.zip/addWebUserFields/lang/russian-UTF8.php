<?php


$langTxt = array(
  
  "addit_fields" => "Дополнительные поля",
  "count_purchase" => "Статистика покупок",
  "sms__checkbox" => "Хочу получать СМС"
  
);




?>